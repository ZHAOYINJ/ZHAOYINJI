# 2022-12-26 Python项目实战-带你爬取豆瓣经典电影排行榜
#1.导入类库
import requests  # 发起网络请求工具 第三方库 pip install requests 类库名
from lxml import etree  # 数据转换类库 pip install lxml
import csv  # 文字类库

# 2.抓取数据，寻找url资源路径
url = 'https://movie.douban.com/top250?start=25&filter='

# 请求头 request 请求的一部分，伪装头才符合https协议正常访问，否则会触发反爬虫机制
# headers={} 括号应该从哪里抓取数据？谷歌浏览器  通行证 User-Agent
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'}

# 3.访问网站拿到数据，并打印网页源代码
reponse = requests.get(url=url, headers=headers)
# print(reponse.text)



# 2022-12-27
#4.数据文本转换成HTML

# 接下来要把这个数据文本转换成HTML,采用reponse
# 首先拿到装所有数据的大盒子div,通过data中的方法，就相当于一个搜索方式给到我们就叫它xpath，
# 这个地方该怎么去定位呢？//双斜杠表示定位，@符号表示定位到第二位，就可以把数据逐一取出来,
# 把取出来的数据定义成一个对象集合moiveItemList，相当于一个电影表单

data = etree.HTML(reponse.text)
movieItemList = data.xpath('//div[@class="info"]')

# 准备一个容器来装每一部电影的数据，首先声明一个movieList电影列表，使用for循环要从电影列表中把每一部电影的数据找出来。
movieList = []

for movieItem in movieItemList:
    # 准备一个字典来保存每一部电影的信息
    movieDict = {}

    # 解析数据
    # 获取标题文本
    title = movieItem.xpath('div[@class="hd"]/a/span[@class="title"]/text()')
    # 获取其他标题
    othertitle = movieItem.xpath(
        'div[@class="hd"]/a/span[@class="other"]/text()')
    # 获取链接，也就是电影的一个详细介绍,拿到a标签下面的href,[0]表示取第一个元素。
    Link = movieItem.xpath('div[@class="hd"]/a/@href')[0]
    # 获取电影评分
    star = movieItem.xpath(
        'div[@class="bd"]/div[@class="star"]/span[@class="rating_num"]/text()')[0]
    # 获取电影简介
    quote = movieItem.xpath('div[@class="bd"]/p[@class="quote"]/span/text()')

    # 填充数据到电影字典，movieDict,title就相当于把字符串拼接转一下，为什么要转呢？这个地方就等于title加上othertitle，填充标题到字典。
    movieDict['title'] = ''.join(title+othertitle)
    movieDict['Link'] = Link
    movieDict['star'] = star
    movieDict['quote'] = quote
    # 打印电影字典
   # print(movieDict)

# 5.将每部电影填充进大容器movieList
    movieList.append(movieDict)
# 6.通过文件I/O保存数据
with open('doubanMovie.csv', 'w', encoding='utf-8', newline='')as f:
    writer = csv.DictWriter(f, fieldnames=['title', 'star', 'quote', 'Link'])
    writer.writeheader()
    for each in movieList:
        writer.writerow(each)
